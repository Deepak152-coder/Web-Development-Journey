let gameName = "spiderman";

gameName = "batman";

console.log(gameName);

const username = "hiteshdotcom";

username = "hitesh";

console.log(username);
