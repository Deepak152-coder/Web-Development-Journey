// && -> and
// || -> or
// ! -> reverse

let isLoggedin = true;
let ispaid = true;

// console.log(isLoggedin && ispaid);

let isEmailuser = true;
let isGoogleuser = false;

console.log(isEmailuser || isGoogleuser);
